﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class GameFlow : MonoBehaviour
{
    [SerializeField] Text textContent;
    [SerializeField] State startingState;
    
    State state;

    void Start()
    {
        state = startingState; 
        //textContent.text = "Chapter 1: First Door";
        textContent.text = state.GetStorytext();    
    }

    // Update is called once per frame
    void Update()
    {
        ManageState();
    }

    private void ManageState()
    {
        var nextStates = state.GetNextState();
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            state = nextStates[0];
        }
        else if (Input.GetKeyDown(KeyCode.Alpha2) && nextStates.Length >=1)
        {
            state = nextStates[1];
        }
        textContent.text = state.GetStorytext();
    }
}
